"""
媒体转录核心引擎
整合媒体文件读取、音频提取和语音转录功能
"""

import asyncio
import uuid
import time
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Callable
from pathlib import Path

from loguru import logger

from models.schemas import (
    MediaFileInfo, TranscriptionResult, TaskInfo, BatchTaskInfo,
    TaskStatus, ProcessOptions, TranscriptionModel, Language, OutputFormat
)
from .downloader import audio_extractor, extract_audio_from_media


class VideoTranscriptionEngine:
    """媒体转录核心引擎"""

    def __init__(self, temp_dir: str = "./temp", task_timeout: int = 3600, keep_temp_files: bool = False):
        """
        初始化引擎

        Args:
            temp_dir: 临时文件目录
            task_timeout: 任务超时时间（秒），默认1小时
            keep_temp_files: 是否保留临时文件（用于调试），默认False
        """
        self.temp_dir = Path(temp_dir)
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self.task_timeout = task_timeout
        self.keep_temp_files = keep_temp_files

        # 任务管理
        self.tasks: Dict[str, TaskInfo] = {}
        self.batch_tasks: Dict[str, BatchTaskInfo] = {}

        # 统计信息
        self.stats = {
            "total_processed": 0,
            "total_success": 0,
            "total_failed": 0,
            "total_processing_time": 0.0,
            "total_timeout": 0
        }

    async def process_video_file(
        self,
        file_path: str,
        options: ProcessOptions,
        progress_callback: Optional[Callable[[str, float, str], None]] = None,
        timeout: Optional[int] = None
    ) -> TranscriptionResult:
        """
        处理单个本地媒体文件

        Args:
            file_path: 媒体文件路径
            options: 处理选项
            progress_callback: 进度回调 (task_id, progress, message)
            timeout: 自定义超时时间（秒），None则使用默认值

        Returns:
            TranscriptionResult: 转录结果

        Raises:
            asyncio.TimeoutError: 任务超时
        """
        task_id = self._generate_task_id()
        task_info = None
        actual_timeout = timeout or self.task_timeout

        try:
            logger.info(f"开始处理媒体文件: {file_path} (超时: {actual_timeout}秒)")
            start_time = time.time()

            # 创建任务记录
            task_info = TaskInfo(
                task_id=task_id,
                file_path=file_path,
                status=TaskStatus.PENDING,
                progress=0,
                started_at=datetime.now(),
                completed_at=None,
                error_message=None,
                media_info=None,
                result=None
            )
            self.tasks[task_id] = task_info

            # 进度回调包装
            def update_progress(progress: float, message: str = ""):
                task_info.progress = int(progress)
                if progress_callback:
                    progress_callback(task_id, progress, message)

            # 1. 获取媒体文件信息
            update_progress(5, "正在读取文件信息...")
            task_info.status = TaskStatus.EXTRACTING

            media_file_info = audio_extractor.get_media_info(file_path)
            task_info.media_info = media_file_info

            logger.info(f"媒体文件信息: {media_file_info.file_name}, 大小: {media_file_info.file_size} 字节")
            update_progress(10, f"读取成功: {media_file_info.file_name}")

            # 2. 提取音频
            def extract_progress(progress: float):
                # 提取进度占10-50%
                total_progress = 10 + (progress * 0.4)
                update_progress(total_progress, "正在提取音频...")

            audio_path = await extract_audio_from_media(
                media_path=file_path,
                optimize=True,
                progress_callback=extract_progress
            )

            logger.info(f"音频提取成功: {audio_path}")
            update_progress(50, "音频提取完成")

            # 3. 语音转录
            task_info.status = TaskStatus.TRANSCRIBING

            def transcribe_progress(progress: float):
                # 转录进度占50-95%
                total_progress = 50 + (progress * 0.45)
                update_progress(total_progress, "正在进行语音识别...")

            # 使用 SenseVoice 转录器
            from .sensevoice_transcriber import create_sensevoice_transcriber
            from models.schemas import TimestampMode

            # 解析时间戳模式：向后兼容 with_timestamps
            ts_mode = options.timestamp_mode
            if ts_mode == TimestampMode.NONE and options.with_timestamps:
                ts_mode = TimestampMode.SENTENCE

            transcriber = create_sensevoice_transcriber(
                model_name=options.model.value if hasattr(options.model, 'value') else str(options.model),
                model_cache_dir=str(self.temp_dir / "models_cache"),
                timestamp_mode=ts_mode.value if hasattr(ts_mode, 'value') else str(ts_mode)
            )

            transcription_result = await transcriber.transcribe_audio(
                audio_path=audio_path,
                language=options.language,
                with_timestamps=options.with_timestamps,
                temperature=options.temperature,
                progress_callback=transcribe_progress,
                timestamp_mode=ts_mode.value if hasattr(ts_mode, 'value') else str(ts_mode)
            )

            # 卸载模型释放内存
            await transcriber.unload_model()

            logger.info(f"转录完成: {len(transcription_result.text)} 字符")
            update_progress(95, "转录完成，正在处理结果...")

            # 4. 清理临时文件（可选保留用于调试）
            if not self.keep_temp_files:
                try:
                    Path(audio_path).unlink()
                    logger.debug(f"已清理临时音频文件: {audio_path}")
                except Exception as e:
                    logger.warning(f"清理临时文件失败: {e}")
            else:
                logger.info(f"保留临时音频文件: {audio_path}")

            # 5. 完成任务
            task_info.status = TaskStatus.COMPLETED
            task_info.result = transcription_result
            task_info.completed_at = datetime.now()

            processing_time = time.time() - start_time

            # 更新统计信息
            self.stats["total_processed"] += 1
            self.stats["total_success"] += 1
            self.stats["total_processing_time"] += processing_time

            update_progress(100, "处理完成")

            logger.info(f"视频处理完成，耗时: {processing_time:.2f}秒")
            return transcription_result

        except asyncio.TimeoutError:
            # 超时处理
            logger.error(f"视频处理超时: {file_path} (超时时间: {actual_timeout}秒)")

            if task_info is not None:
                task_info.status = TaskStatus.FAILED
                task_info.error_message = f"处理超时 (超过 {actual_timeout} 秒)"
                task_info.completed_at = datetime.now()

            self.stats["total_processed"] += 1
            self.stats["total_failed"] += 1
            self.stats["total_timeout"] += 1

            if progress_callback:
                progress_callback(task_id, 0, f"处理超时")

            raise Exception(f"视频处理超时 (超过 {actual_timeout} 秒)")

        except Exception as e:
            # 错误处理
            logger.error(f"视频处理失败: {e}")

            if task_info is not None:
                task_info.status = TaskStatus.FAILED
                task_info.error_message = str(e)
                task_info.completed_at = datetime.now()

            self.stats["total_processed"] += 1
            self.stats["total_failed"] += 1

            if progress_callback:
                progress_callback(task_id, 0, f"处理失败: {str(e)}")

            raise Exception(f"视频处理失败: {str(e)}")

    async def process_video_url(
        self,
        url: str,
        options: ProcessOptions,
        progress_callback: Optional[Callable[[str, float, str], None]] = None
    ) -> TranscriptionResult:
        """
        处理媒体URL (下载后转录)

        注意: 此功能需要额外的下载库支持。
        当前版本返回错误提示，请使用 process_video_file() 处理本地文件。

        Args:
            url: 视频URL
            options: 处理选项
            progress_callback: 进度回调 (task_id, progress, message)

        Returns:
            TranscriptionResult: 转录结果

        Raises:
            NotImplementedError: 当URL下载功能未启用时
        """
        logger.warning(f"尝试处理媒体URL: {url}")

        raise NotImplementedError(
            "URL下载功能未启用。当前版本仅支持本地文件处理。\n"
            "请使用以下方法之一:\n"
            "1. 通过 Web 界面上传音视频文件\n"
            "2. 使用 POST /api/v1/transcribe/file API 上传文件\n"
            "3. 使用命令行: python webmain.py transcribe <本地文件路径>\n\n"
            "如需URL下载功能，请:\n"
            "- 安装 yt-dlp: pip install yt-dlp\n"
            "- 在配置中设置 ENABLE_PLATFORM_DOWNLOAD=true"
        )

    async def process_batch_files(
        self,
        file_paths: List[str],
        options: ProcessOptions,
        max_concurrent: int = 3,
        progress_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None
    ) -> BatchTaskInfo:
        """
        批量处理媒体文件

        Args:
            file_paths: 媒体文件路径列表
            options: 处理选项
            max_concurrent: 最大并发数
            progress_callback: 进度回调 (batch_id, status_info)

        Returns:
            BatchTaskInfo: 批量任务信息
        """
        batch_id = self._generate_batch_id()

        try:
            logger.info(f"开始批量处理 {len(file_paths)} 个媒体文件")

            # 创建批量任务记录
            batch_info = BatchTaskInfo(
                batch_id=batch_id,
                total_count=len(file_paths),
                pending_count=len(file_paths),
                completed_count=0,
                failed_count=0
            )
            self.batch_tasks[batch_id] = batch_info

            # 创建信号量限制并发数
            semaphore = asyncio.Semaphore(max_concurrent)

            async def process_single_file(file_path: str) -> Optional[TranscriptionResult]:
                async with semaphore:
                    try:
                        def single_progress(task_id: str, progress: float, message: str):
                            # 更新批量任务进度
                            self._update_batch_progress(batch_id, progress_callback)

                        result = await self.process_video_file(
                            file_path=file_path,
                            options=options,
                            progress_callback=single_progress
                        )

                        # 更新批量任务统计
                        batch_info.completed_count += 1
                        batch_info.pending_count -= 1

                        return result

                    except Exception as e:
                        logger.error(f"文件处理失败: {file_path}, 错误: {e}")

                        # 更新批量任务统计
                        batch_info.failed_count += 1
                        batch_info.pending_count -= 1

                        return None

            # 并发执行处理任务
            tasks = [process_single_file(file_path) for file_path in file_paths]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # 处理结果
            success_count = len([r for r in results if r is not None and not isinstance(r, Exception)])

            logger.info(f"批量处理完成，成功: {success_count}/{len(file_paths)}")

            # 最终进度回调
            if progress_callback:
                progress_callback(batch_id, {
                    "total": len(file_paths),
                    "completed": batch_info.completed_count,
                    "failed": batch_info.failed_count,
                    "success_rate": success_count / len(file_paths) if file_paths else 0
                })

            return batch_info

        except Exception as e:
            logger.error(f"批量处理失败: {e}")
            raise Exception(f"批量处理失败: {str(e)}")

    def _update_batch_progress(
        self,
        batch_id: str,
        progress_callback: Optional[Callable[[str, Dict[str, Any]], None]]
    ):
        """更新批量任务进度"""
        if batch_id in self.batch_tasks and progress_callback:
            batch_info = self.batch_tasks[batch_id]
            progress_callback(batch_id, {
                "total": batch_info.total_count,
                "completed": batch_info.completed_count,
                "failed": batch_info.failed_count,
                "pending": batch_info.pending_count
            })

    def get_task_status(self, task_id: str) -> Optional[TaskInfo]:
        """获取任务状态"""
        return self.tasks.get(task_id)

    def get_batch_status(self, batch_id: str) -> Optional[BatchTaskInfo]:
        """获取批量任务状态"""
        return self.batch_tasks.get(batch_id)

    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            **self.stats,
            "active_tasks": len([t for t in self.tasks.values()
                               if t.status in [TaskStatus.PENDING, TaskStatus.EXTRACTING,
                                             TaskStatus.TRANSCRIBING]]),
            "total_tasks": len(self.tasks),
            "average_processing_time": (
                self.stats["total_processing_time"] / self.stats["total_processed"]
                if self.stats["total_processed"] > 0 else 0
            )
        }

    def cleanup_old_tasks(self, older_than_hours: int = 24) -> int:
        """清理旧任务记录"""
        try:
            current_time = datetime.now()
            cleaned_count = 0

            # 清理单个任务
            tasks_to_remove = []
            for task_id, task_info in self.tasks.items():
                if task_info.completed_at:
                    hours_diff = (current_time - task_info.completed_at).total_seconds() / 3600
                    if hours_diff > older_than_hours:
                        tasks_to_remove.append(task_id)

            for task_id in tasks_to_remove:
                del self.tasks[task_id]
                cleaned_count += 1

            # 清理批量任务
            batches_to_remove = []
            for batch_id, batch_info in self.batch_tasks.items():
                hours_diff = (current_time - batch_info.created_at).total_seconds() / 3600
                if hours_diff > older_than_hours:
                    batches_to_remove.append(batch_id)

            for batch_id in batches_to_remove:
                del self.batch_tasks[batch_id]
                cleaned_count += 1

            if cleaned_count > 0:
                logger.info(f"清理了 {cleaned_count} 个旧任务记录")

            return cleaned_count

        except Exception as e:
            logger.error(f"任务清理失败: {e}")
            return 0

    async def cleanup_temp_files(self) -> int:
        """清理临时文件"""
        return audio_extractor.cleanup_files()

    def _generate_task_id(self) -> str:
        """生成任务ID"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        random_suffix = uuid.uuid4().hex[:8]
        return f"task_{timestamp}_{random_suffix}"

    def _generate_batch_id(self) -> str:
        """生成批量任务ID"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        random_suffix = uuid.uuid4().hex[:8]
        return f"batch_{timestamp}_{random_suffix}"


# 全局引擎实例
transcription_engine = VideoTranscriptionEngine()


async def transcribe_video_file(
    file_path: str,
    model: TranscriptionModel = TranscriptionModel.SENSEVOICE_SMALL,
    language: Language = Language.AUTO,
    with_timestamps: bool = False,
    output_format: OutputFormat = OutputFormat.JSON,
    progress_callback: Optional[Callable[[str, float, str], None]] = None
) -> TranscriptionResult:
    """
    转录媒体文件的便捷函数

    Args:
        file_path: 媒体文件路径
        model: 语音识别模型
        language: 语言
        with_timestamps: 是否包含时间戳
        output_format: 输出格式
        progress_callback: 进度回调

    Returns:
        TranscriptionResult: 转录结果
    """
    options = ProcessOptions(
        model=model,
        language=language,
        with_timestamps=with_timestamps,
        output_format=output_format,
        enable_gpu=True,
        temperature=0.0
    )

    return await transcription_engine.process_video_file(
        file_path=file_path,
        options=options,
        progress_callback=progress_callback
    )


if __name__ == "__main__":
    # 测试代码
    import asyncio

    async def test():
        engine = VideoTranscriptionEngine()

        try:
            print("测试引擎初始化...")
            print(f"统计信息: {engine.get_statistics()}")

            # 测试任务ID生成
            task_id = engine._generate_task_id()
            batch_id = engine._generate_batch_id()
            print(f"任务ID: {task_id}")
            print(f"批量ID: {batch_id}")

            # 测试清理
            cleaned_tasks = engine.cleanup_old_tasks(0)
            cleaned_files = await engine.cleanup_temp_files()
            print(f"清理任务: {cleaned_tasks}, 清理文件: {cleaned_files}")

        except Exception as e:
            print(f"测试失败: {e}")

    # asyncio.run(test())
