"""
转录服务
封装媒体转录的业务逻辑
"""

import asyncio
import uuid
import time
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any, Callable, Set, Tuple

from loguru import logger

from config import settings, Settings
from models.schemas import (
    TranscriptionResult, TaskInfo, TaskStatus,
    ProcessOptions, TranscriptionModel, Language, OutputFormat, TimestampMode,
    TranscriptionMode
)
from core.downloader import AudioExtractor
from .file_service import FileService
from .task_service import TaskService
from utils.paragraph_formatter import format_paragraphs


def _apply_paragraph_formatting(result, config):
    """对转录结果应用段落格式化，格式化后为空则回退到原文。"""
    original_text = result.text
    result.paragraphs = format_paragraphs(
        result,
        silence_threshold=getattr(config, 'PARAGRAPH_SILENCE_THRESHOLD', 1.5),
        max_length=getattr(config, 'PARAGRAPH_MAX_LENGTH', 250),
        min_length=getattr(config, 'PARAGRAPH_MIN_LENGTH', 30),
    )
    if result.paragraphs:
        joined = "\n\n".join(
            p.text for p in result.paragraphs if p.text.strip()
        )
        result.text = joined if joined else original_text


class TranscriptionService:
    """
    转录服务
    协调媒体音频提取和语音转录的完整流程
    """

    def __init__(self, config: Optional[Settings] = None):
        """
        初始化转录服务

        Args:
            config: 应用配置，默认使用全局配置
        """
        self.config = config or settings

        # 初始化组件
        self.audio_extractor = AudioExtractor(
            temp_dir=self.config.TEMP_DIR,
            cleanup_after=self.config.CLEANUP_AFTER
        )
        self.file_service = FileService(self.config)
        self.task_service = TaskService(self.config)
        self.running_tasks: Dict[str, asyncio.Task] = {}
        self.task_temp_files: Dict[str, Set[str]] = {}

        logger.info("转录服务初始化完成")

    async def transcribe_file(
        self,
        file_path: str,
        options: Optional[ProcessOptions] = None,
        progress_callback: Optional[Callable[[str, float, str], None]] = None,
        timeout: Optional[int] = None,
        task_id: Optional[str] = None
    ) -> TranscriptionResult:
        """
        转录单个媒体文件

        Args:
            file_path: 媒体文件路径
            options: 处理选项
            progress_callback: 进度回调函数 (task_id, progress, message)
            timeout: 自定义超时时间（秒）
            task_id: 外部预生成的任务ID（由 create_task_id 生成）

        Returns:
            TranscriptionResult: 转录结果
        """
        # 使用默认选项
        if options is None:
            options = ProcessOptions(
                model=TranscriptionModel(self.config.DEFAULT_MODEL),
                language=Language(self.config.DEFAULT_LANGUAGE),
                with_timestamps=self.config.ENABLE_WORD_TIMESTAMPS,
                output_format=OutputFormat.TXT,
                enable_gpu=self.config.ENABLE_GPU,
                temperature=self.config.DEFAULT_TEMPERATURE
            )

        # 创建或恢复任务
        if task_id and self.task_service.get_task(task_id):
            # 外部预注册的 task_id，更新已有 TaskInfo
            task_info = self.task_service.get_task(task_id)
            task_info.file_path = file_path
            task_info.started_at = datetime.now()
        else:
            task_id = self._generate_task_id()
            task_info = TaskInfo(
                task_id=task_id,
                file_path=file_path,
                status=TaskStatus.PENDING,
                progress=0,
                started_at=datetime.now(),
                completed_at=None,
                error_message=None,
                media_info=None,
                result=None
            )
            self.task_service.add_task(task_id, task_info)

        timeout_seconds = timeout if timeout is not None else self.config.TASK_TIMEOUT

        async def _run_pipeline() -> TranscriptionResult:
            # 验证文件
            await self._validate_file(file_path, task_id, progress_callback)

            # 获取媒体信息（同步 ffprobe 调用，放入线程池避免阻塞事件循环）
            media_info = await asyncio.to_thread(self.audio_extractor.get_media_info, file_path)
            task_info.media_info = media_info

            # 提取音频
            self.task_service.update_task_status(task_id, TaskStatus.EXTRACTING)
            audio_path, raw_audio_path = await self._extract_audio(
                file_path, task_id, progress_callback
            )
            self._register_temp_file(task_id, audio_path)

            # 执行转录
            self.task_service.update_task_status(task_id, TaskStatus.TRANSCRIBING)
            return await self._transcribe(
                audio_path, options, task_id, progress_callback,
                raw_audio_path=raw_audio_path,
            )

        try:
            logger.info(f"开始处理媒体文件: {file_path}")
            self._register_running_task(task_id)

            # 强制执行任务超时（TASK_TIMEOUT 配置在此真正生效）
            result = await asyncio.wait_for(_run_pipeline(), timeout=timeout_seconds)

            # 更新任务状态
            task_info.result = result
            task_info.completed_at = datetime.now()
            task_info.progress = 100
            self.task_service.update_task_status(task_id, TaskStatus.COMPLETED, progress=100)

            if progress_callback:
                progress_callback(task_id, 100, "处理完成")

            logger.info(f"媒体处理完成: {file_path}")
            return result

        except asyncio.CancelledError:
            logger.warning(f"媒体处理被终止: {file_path}")
            task_info.error_message = "任务已终止"
            task_info.completed_at = datetime.now()
            self.task_service.update_task_status(task_id, TaskStatus.CANCELLED, error_message="任务已终止")

            if progress_callback:
                progress_callback(task_id, task_info.progress, "任务已终止")

            raise

        except asyncio.TimeoutError:
            # 超时处理
            timeout_used = timeout or self.config.TASK_TIMEOUT
            logger.error(f"媒体处理超时: {file_path} (超时时间: {timeout_used}秒)")
            err_msg = f"处理超时 (超过 {timeout_used} 秒)"
            task_info.error_message = err_msg
            task_info.completed_at = datetime.now()
            self.task_service.update_task_status(task_id, TaskStatus.FAILED, error_message=err_msg)

            if progress_callback:
                progress_callback(task_id, 0, "处理超时")

            raise Exception(err_msg)

        except Exception as e:
            logger.error(f"媒体处理失败: {e}")
            task_info.error_message = str(e)
            task_info.completed_at = datetime.now()
            self.task_service.update_task_status(task_id, TaskStatus.FAILED, error_message=str(e))

            if progress_callback:
                progress_callback(task_id, 0, f"处理失败: {str(e)}")

            raise Exception(f"媒体处理失败: {str(e)}")

        finally:
            await self._cleanup_task_temp_files(task_id)
            self.running_tasks.pop(task_id, None)
            self.task_temp_files.pop(task_id, None)

    async def transcribe_batch(
        self,
        file_paths: List[str],
        options: Optional[ProcessOptions] = None,
        max_concurrent: Optional[int] = None,
        progress_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None
    ) -> Dict[str, Any]:
        """
        批量转录媒体文件

        Args:
            file_paths: 媒体文件路径列表
            options: 处理选项
            max_concurrent: 最大并发数
            progress_callback: 进度回调函数 (batch_id, status_info)

        Returns:
            Dict[str, Any]: 批量处理结果统计
        """
        batch_id = self._generate_batch_id()

        if options is None:
            options = ProcessOptions(
                model=TranscriptionModel(self.config.DEFAULT_MODEL),
                language=Language(self.config.DEFAULT_LANGUAGE),
                with_timestamps=self.config.ENABLE_WORD_TIMESTAMPS,
                output_format=OutputFormat.TXT,
                enable_gpu=self.config.ENABLE_GPU,
                temperature=self.config.DEFAULT_TEMPERATURE
            )

        if max_concurrent is None:
            max_concurrent = self.config.MAX_CONCURRENT_TASKS

        logger.info(f"开始批量处理 {len(file_paths)} 个媒体文件")

        # 创建信号量限制并发数
        semaphore = asyncio.Semaphore(max_concurrent)

        async def process_single(file_path: str) -> Optional[TranscriptionResult]:
            async with semaphore:
                try:
                    def single_progress(task_id: str, progress: float, message: str):
                        if progress_callback:
                            # 更新批量任务进度
                            self._update_batch_progress(batch_id, progress_callback)

                    return await self.transcribe_file(
                        file_path=file_path,
                        options=options,
                        progress_callback=single_progress
                    )
                except Exception as e:
                    logger.error(f"文件处理失败: {file_path}, 错误: {e}")
                    return None

        # 并发执行处理任务
        tasks = [process_single(path) for path in file_paths]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # 统计结果
        success_count = sum(1 for r in results if r is not None and not isinstance(r, Exception))
        failed_count = len(results) - success_count

        batch_result = {
            "batch_id": batch_id,
            "total": len(file_paths),
            "success": success_count,
            "failed": failed_count,
            "success_rate": success_count / len(file_paths) if file_paths else 0
        }

        logger.info(f"批量处理完成: {success_count}/{len(file_paths)} 成功")

        if progress_callback:
            progress_callback(batch_id, batch_result)

        return batch_result

    # ============================================================
    # 私有方法
    # ============================================================

    async def _validate_file(
        self,
        file_path: str,
        task_id: str,
        progress_callback: Optional[Callable[[str, float, str], None]]
    ) -> None:
        """验证文件"""
        if progress_callback:
            progress_callback(task_id, 5, "正在验证文件...")

        # 检查文件是否存在
        path = Path(file_path)
        if not path.exists():
            raise Exception(f"文件不存在: {file_path}")

        # 检查文件大小
        file_size = path.stat().st_size
        max_size = self.config.MAX_FILE_SIZE * 1024 * 1024  # MB to bytes
        if file_size > max_size:
            raise Exception(
                f"文件大小超过限制 ({self.config.MAX_FILE_SIZE}MB)"
            )

        # 检查文件格式
        if not self.file_service.is_supported_file(file_path):
            raise Exception(f"不支持的媒体格式: {path.suffix}")

    async def _extract_audio(
        self,
        media_path: str,
        task_id: str,
        progress_callback: Optional[Callable[[str, float, str], None]]
    ) -> Tuple[str, str]:
        """
        提取音频

        Returns:
            (optimized_audio_path, raw_audio_path) 元组
        """
        def update_progress(progress: float):
            if progress_callback:
                total_progress = 10 + (progress * 0.4)
                progress_callback(task_id, total_progress, "正在提取音频...")

        raw_audio_path = await self.audio_extractor.extract_audio(
            media_path=media_path,
            output_format="wav",
            progress_callback=lambda p: update_progress(p * 0.5) if progress_callback else None
        )
        self._register_temp_file(task_id, raw_audio_path)

        optimized_path = await self.audio_extractor.optimize_audio_for_transcription(
            audio_path=raw_audio_path,
            progress_callback=lambda p: update_progress(50 + p * 0.5) if progress_callback else None
        )

        if progress_callback:
            progress_callback(task_id, 50, "音频提取完成")

        return optimized_path, raw_audio_path

    async def _transcribe(
        self,
        audio_path: str,
        options: ProcessOptions,
        task_id: str,
        progress_callback: Optional[Callable[[str, float, str], None]],
        raw_audio_path: Optional[str] = None,
    ) -> TranscriptionResult:
        """执行转录 (使用独立转录器实例)"""
        from core.sensevoice_transcriber import create_sensevoice_transcriber
        from utils.audio.chunking import AudioChunker

        # 获取音频时长（同步 ffprobe 调用，放入线程池避免阻塞事件循环）
        chunker = AudioChunker()
        audio_duration = await asyncio.to_thread(chunker.get_audio_duration, audio_path)

        # 智能设备选择：启用分块时可以使用 GPU 处理更长的音频
        device = "cuda" if options.enable_gpu else "cpu"

        # 只有在禁用分块且音频超过 30 分钟时才强制使用 CPU
        enable_chunking = getattr(self.config, 'ENABLE_AUDIO_CHUNKING', True)
        if not enable_chunking and audio_duration > 1800 and device == "cuda":
            logger.warning(f"音频时长 {audio_duration:.1f}s 超过 30 分钟且分块未启用，自动切换到 CPU 模式以避免 OOM")
            device = "cpu"
        elif enable_chunking and audio_duration > 1800 and device == "cuda":
            logger.info(f"音频时长 {audio_duration:.1f}s 较长，但已启用分块处理，继续使用 GPU")

        logger.info(f"音频时长: {audio_duration:.1f}s, 使用设备: {device}")

        # 解析时间戳模式：向后兼容 with_timestamps 布尔参数
        timestamp_mode = options.timestamp_mode
        if timestamp_mode == TimestampMode.NONE and options.with_timestamps:
            timestamp_mode = TimestampMode.SENTENCE

        # 创建独立的转录器实例
        transcriber = create_sensevoice_transcriber(
            model_name=options.model.value if hasattr(options.model, 'value') else str(options.model),
            device=device,
            model_cache_dir=self.config.MODEL_CACHE_DIR,
            enable_punctuation=getattr(self.config, 'ENABLE_PUNCTUATION', True),
            clean_special_tokens=getattr(self.config, 'CLEAN_SPECIAL_TOKENS', True),
            # 音频分块处理配置
            enable_chunking=getattr(self.config, 'ENABLE_AUDIO_CHUNKING', True),
            chunk_duration_seconds=getattr(self.config, 'CHUNK_DURATION_SECONDS', 180),
            chunk_overlap_seconds=getattr(self.config, 'CHUNK_OVERLAP_SECONDS', 2),
            min_duration_for_chunking=getattr(self.config, 'MIN_DURATION_FOR_CHUNKING', 300),
            # 逐字时间戳模式
            timestamp_mode=timestamp_mode.value if hasattr(timestamp_mode, 'value') else str(timestamp_mode)
        )

        def update_progress(progress: float):
            if progress_callback:
                total_progress = 50 + (progress * 0.45)
                progress_callback(task_id, total_progress, "正在进行语音识别...")

        # 检测音频停顿位置（用于优化字幕切分）
        # 在原始未优化音频上检测，确保时间轴与原始视频一致
        timestamp_mode_str = timestamp_mode.value if hasattr(timestamp_mode, 'value') else str(timestamp_mode)
        silence_ranges = None
        if timestamp_mode_str in ("char", "sentence"):
            try:
                silence_source = raw_audio_path or audio_path
                # pydub 全量解码 + 静音分析是同步重负载，放入线程池避免阻塞事件循环
                silence_ranges = await asyncio.to_thread(
                    self.audio_extractor.detect_silence_ranges,
                    silence_source,
                    300,
                    -40,
                    10,
                )
                if silence_ranges:
                    logger.info(f"检测到 {len(silence_ranges)} 个音频停顿位置，用于优化字幕切分")
            except Exception as e:
                logger.warning(f"检测音频停顿位置失败，跳过: {e}")

        try:
            result = await transcriber.transcribe_audio(
                audio_path=audio_path,
                language=options.language,
                with_timestamps=options.with_timestamps,
                temperature=options.temperature,
                progress_callback=update_progress,
                timestamp_mode=timestamp_mode.value if hasattr(timestamp_mode, 'value') else str(timestamp_mode),
                silence_ranges=silence_ranges,
                raw_audio_path=raw_audio_path
            )
        finally:
            # 卸载模型释放内存（任务被取消或超时中断时也必须执行，避免显存泄漏）
            await transcriber.unload_model()

        if progress_callback:
            progress_callback(task_id, 95, "转录完成")

        # 段落格式化 — 仅文本模式和旧版模式需要
        mode = getattr(options, 'transcription_mode', TranscriptionMode.LEGACY)
        if mode in (TranscriptionMode.TEXT, TranscriptionMode.LEGACY):
            if getattr(self.config, 'ENABLE_PARAGRAPH_FORMATTING', True):
                try:
                    _apply_paragraph_formatting(result, self.config)
                except Exception as e:
                    logger.warning(f"段落格式化失败，跳过: {e}")

        return result

    async def _cleanup_temp_files(self, audio_path: str) -> None:
        """清理临时文件"""
        try:
            Path(audio_path).unlink(missing_ok=True)
        except Exception as e:
            logger.warning(f"清理临时文件失败: {e}")

    async def _cleanup_task_temp_files(self, task_id: str) -> None:
        """清理任务关联的临时文件。"""
        temp_files = self.task_temp_files.get(task_id, set())
        for file_path in list(temp_files):
            await self._cleanup_temp_files(file_path)

    def _register_running_task(self, task_id: str) -> None:
        """记录当前协程任务，便于外部取消。"""
        current_task = asyncio.current_task()
        if current_task:
            self.running_tasks[task_id] = current_task
        self.task_temp_files.setdefault(task_id, set())

    def _register_temp_file(self, task_id: str, file_path: str) -> None:
        """记录任务中产生的临时文件。"""
        if not file_path:
            return
        self.task_temp_files.setdefault(task_id, set()).add(file_path)

    def _update_batch_progress(
        self,
        batch_id: str,
        progress_callback: Callable[[str, Dict[str, Any]], None]
    ) -> None:
        """更新批量任务进度"""
        stats = self.task_service.get_statistics()
        progress_callback(batch_id, {
            "total": stats.get("total_tasks", 0),
            "completed": stats.get("total_success", 0),
            "failed": stats.get("total_failed", 0),
            "pending": stats.get("active_tasks", 0)
        })

    def _generate_task_id(self) -> str:
        """生成任务 ID"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        random_suffix = uuid.uuid4().hex[:8]
        return f"task_{timestamp}_{random_suffix}"

    def _generate_batch_id(self) -> str:
        """生成批量任务 ID"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        random_suffix = uuid.uuid4().hex[:8]
        return f"batch_{timestamp}_{random_suffix}"

    def create_task_id(self) -> str:
        """生成 task_id 并预注册到 TaskService，用于异步提交场景。"""
        task_id = self._generate_task_id()
        task_info = TaskInfo(
            task_id=task_id,
            file_path="",
            status=TaskStatus.PENDING,
            progress=0,
            started_at=None,
            completed_at=None,
            error_message=None,
            media_info=None,
            result=None
        )
        self.task_service.add_task(task_id, task_info)
        self.task_temp_files.setdefault(task_id, set())
        return task_id

    def register_task_temp_file(self, task_id: str, file_path: str) -> None:
        """预注册临时文件，转录完成后统一清理。"""
        if not file_path:
            return
        self.task_temp_files.setdefault(task_id, set()).add(file_path)

    # ============================================================
    # 公共方法
    # ============================================================

    def get_task_status(self, task_id: str) -> Optional[TaskInfo]:
        """获取任务状态"""
        return self.task_service.get_task(task_id)

    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        return self.task_service.get_statistics()

    async def cancel_task(self, task_id: str) -> Dict[str, Any]:
        """取消正在运行的任务。"""
        task_info = self.task_service.get_task(task_id)
        if not task_info:
            return {"success": False, "reason": "not_found", "message": "任务不存在"}

        if task_info.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED]:
            return {
                "success": False,
                "reason": "not_active",
                "message": f"任务当前状态为 {task_info.status.value}，无法终止"
            }

        running_task = self.running_tasks.get(task_id)
        if not running_task:
            task_info.status = TaskStatus.CANCELLED
            task_info.error_message = "任务已终止"
            task_info.completed_at = datetime.now()
            await self._cleanup_task_temp_files(task_id)
            self.running_tasks.pop(task_id, None)
            self.task_temp_files.pop(task_id, None)
            return {"success": True, "reason": "marked_cancelled", "message": "任务已标记为终止"}

        running_task.cancel()
        return {"success": True, "reason": "cancel_requested", "message": "已发送终止请求"}

    async def cleanup_old_tasks(self, older_than_hours: int = 24) -> int:
        """清理旧任务"""
        return self.task_service.cleanup_old_tasks(older_than_hours)

    async def cleanup_temp_files(self) -> int:
        """清理临时文件"""
        return self.audio_extractor.cleanup_files()

    def build_text_options(self, model: str = "sensevoice-small", language: str = "auto",
                           enable_gpu: Optional[bool] = None, temperature: float = 0.0) -> ProcessOptions:
        """构建文本转录选项：带标点、分段，无时间戳。"""
        return ProcessOptions(
            model=TranscriptionModel(model),
            language=Language(language),
            with_timestamps=False,
            timestamp_mode=TimestampMode.NONE,
            output_format=OutputFormat.TXT,
            enable_gpu=enable_gpu if enable_gpu is not None else self.config.ENABLE_GPU,
            temperature=temperature,
            transcription_mode=TranscriptionMode.TEXT,
        )

    def build_subtitle_options(self, model: str = "sensevoice-small", language: str = "auto",
                               timestamp_mode: str = "sentence",
                               enable_gpu: Optional[bool] = None, temperature: float = 0.0) -> ProcessOptions:
        """构建字幕生成选项：带时间戳分段，无标点段落。"""
        try:
            ts_mode = TimestampMode(timestamp_mode)
        except ValueError:
            ts_mode = TimestampMode.SENTENCE
        if ts_mode == TimestampMode.NONE:
            ts_mode = TimestampMode.SENTENCE
        return ProcessOptions(
            model=TranscriptionModel(model),
            language=Language(language),
            with_timestamps=True,
            timestamp_mode=ts_mode,
            output_format=OutputFormat.JSON,
            enable_gpu=enable_gpu if enable_gpu is not None else self.config.ENABLE_GPU,
            temperature=temperature,
            transcription_mode=TranscriptionMode.SUBTITLE,
        )

    def reformat_paragraphs(self) -> int:
        """
        对所有已完成任务的转录结果重新应用段落格式化。
        用于历史记录补充分段。

        Returns:
            int: 重新格式化的任务数量
        """
        if not getattr(self.config, 'ENABLE_PARAGRAPH_FORMATTING', True):
            return 0

        count = 0
        for task_id, task_info in self.task_service.tasks.items():
            if task_info.status != TaskStatus.COMPLETED or not task_info.result:
                continue

            result = task_info.result
            try:
                _apply_paragraph_formatting(result, self.config)
                count += 1
            except Exception as e:
                logger.warning(f"任务 {task_id} 段落重新格式化失败: {e}")

        logger.info(f"历史记录段落格式化完成: {count} 个任务")
        return count
